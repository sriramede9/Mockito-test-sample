package com.example.demo.business.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListMockTestClass {

	List list = mock(List.class);

	@Test
	@DisplayName("list_mock_test")
	void test() {

		when(list.size()).thenReturn(5).thenReturn(10);

		assertEquals(5, list.size());
		assertEquals(10, list.size());
	}

	@Test
	@DisplayName("list_mock_test_get(0)")
	void test_list_get_1() {

		when(list.get(Mockito.anyInt())).thenReturn(5);

		assertEquals(5, list.get(1000));
		assertEquals(5, list.get(20000));
	}

	@Test
	@DisplayName("list_mock_test_verification_Test")
	void test_verification_basis() {

		String value = (String) list.get(0);

		// to check get method is called
//		Mockito.verify(list).get(0);
		Mockito.verify(list, Mockito.times(1)).get(0);
	}

	@Test
	@DisplayName("list_mock_test_verify_arguements")
	void test_verification_arguements() {

		list.add("checking this arguement");
		
		ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		
		verify(list).add(captor.capture());
		
		assertEquals("checking this arguement", captor.getValue());

//		Mockito.verify(list, Mockito.times(1)).get(0);
	}
	
	@Test
	@DisplayName("list_mock_test_verify_arguements_mutliple")
	void test_verification_arguements_mutliple() {
		
		list.add("checking this arguement");
		list.add("checking this arguement2");
		
		ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
		verify(list,times(2)).add(captor.capture());
		
		List<String> allvalues=captor.getAllValues();
		
		assertEquals("checking this arguement", allvalues.get(0));
		assertEquals("checking this arguement2", allvalues.get(1));
		
//		Mockito.verify(list, Mockito.times(1)).get(0);
	}

}
