package com.example.demo.business.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.demo.HelloController;
import com.example.demo.controller.ItemController;
import com.example.demo.model.Item;
import com.example.demo.service.ItemBusinessService;

//@SpringBootTest
@RunWith(SpringRunner.class)
@WebMvcTest(ItemController.class)
class ItemControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ItemBusinessService itemBusinessServiceMockBean;

	@Test
	@DisplayName("item_controller_test_all_items__jpa")
	void all_items_controller_jpa() throws Exception {

		when(itemBusinessServiceMockBean.getAllItemsRepositoryItem()).thenReturn(Arrays.asList(
				new Item(1, "db-item", 10, 100), new Item(2, "db-item-2", 5, 22), new Item(3, "db-item-3", 8, 16)));

		RequestBuilder accept = MockMvcRequestBuilders.get("/all-items").accept(MediaType.APPLICATION_JSON);

		MvcResult andReturn = mockMvc.perform(accept).andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(content().json("[{\"id\":1,\"name\":\"db-item\",\"price\":10,\"quantity\":100},{\"id\":2,\"name\":\"db-item-2\",\"price\":5,\"quantity\":22},{}]")).andReturn();

		System.out.println(andReturn.getResponse().getContentAsString());

	}

	@Test
	@DisplayName("item_controller_test_business_service")
	void hello_world_basic_test_service_layer() throws Exception {

		when(itemBusinessServiceMockBean.getHardcodedItem()).thenReturn(new Item(1, "ball", 10, 100));

		RequestBuilder accept = MockMvcRequestBuilders.get("/db-world").accept(MediaType.APPLICATION_JSON);

		MvcResult andReturn = mockMvc.perform(accept).andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(content().json("{\"id\":1,\"name\":\"ball\",\"price\":10,\"quantity\":100}")).andReturn();

		System.out.println(andReturn.getResponse().getContentAsString());

	}

	@Test
	@DisplayName("item_controller_test")
	void hello_world_basic_test() throws Exception {

		RequestBuilder accept = MockMvcRequestBuilders.get("/d-world").accept(MediaType.APPLICATION_JSON);

		MvcResult andReturn = mockMvc.perform(accept).andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(content().json("{\"id\":1,\"name\":\"ball\",\"price\":10,\"quantity\":100}")).andReturn();

		System.out.println(andReturn.getResponse().getContentAsString());

	}
}
