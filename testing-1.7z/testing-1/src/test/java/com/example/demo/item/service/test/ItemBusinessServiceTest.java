package com.example.demo.item.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.model.Item;
import com.example.demo.service.ItemBusinessService;
import com.example.demo.service.ItemRepository;

@SpringBootTest
public class ItemBusinessServiceTest {

	@InjectMocks
	ItemBusinessService itemBusinessServiceMock;

	@Mock
	ItemRepository itemRepositoryMock;

	@Test
	@DisplayName("item_service_get_all_items_test")
	public void all_items_test() {

		when(itemRepositoryMock.findAll()).thenReturn(Arrays.asList(new Item(1, "db-item", 10, 100),
				new Item(2, "db-item-2", 5, 22), new Item(3, "db-item-3", 8, 16)));

		List<Item> items_expected = itemBusinessServiceMock.getAllItemsRepositoryItem();

//		assertEquals(item_0, new Item(1, "db-item", 10, 100));

		List<Item> actual = Arrays.asList(new Item(1, "db-item", 10, 100), new Item(2, "db-item-2", 5, 22),
				new Item(3, "db-item-3", 8, 16));

		assertEquals(items_expected.get(0).getValue(), 1000);

	}

}
