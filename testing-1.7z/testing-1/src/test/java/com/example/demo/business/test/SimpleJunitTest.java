package com.example.demo.business.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.business.BusinessClass;
import com.example.demo.business.SomeDataServeImpl;
import com.example.demo.business.SomeDataService;

//@ContextConfiguration(classes = { BusinessClass.class })
@SpringBootTest
public class SimpleJunitTest {

	@InjectMocks
	static BusinessClass bc = new BusinessClass();

	// mock this service and inject into injectmock class works with setter
	
	@Mock
	static SomeDataService someDataServiceMock = mock(SomeDataService.class);

//	@Before
//	@DisplayName("test_Business_obj")
//	public static void create_test_Obj() {
//
//		bc.setSomeDataService(someDataServiceMock);
//		
//
//	}

	@Test
	@DisplayName("test_Calculate_sum_positive")
	public void testCalculateSum_basic() {

//		BusinessClass bctest = new BusinessClass();

//		int result = bc.calculateSum(new int[] { 1, 2, 3, 4 });
//		int result = bc.calculateSumDataService();

//		SomeDataService someDataServiceMock = mock(SomeDataService.class);
		when(someDataServiceMock.retrieveAllData()).thenReturn(new int[] { 1, 2, 3, 4 });
		bc.setSomeDataService(someDataServiceMock);
		assertEquals(10, bc.calculateSumDataService());
	}

	@Test
	@DisplayName("test_Calculate_sum_zero")
	public void testCalculateSum_empty() {

//		BusinessClass bc = new BusinessClass();

		when(someDataServiceMock.retrieveAllData()).thenReturn(new int[] {});
		bc.setSomeDataService(someDataServiceMock);

		int result = bc.calculateSumDataService();

		assertEquals(0, result);
	}

}
