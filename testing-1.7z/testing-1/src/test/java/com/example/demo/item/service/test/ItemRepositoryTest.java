package com.example.demo.item.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.demo.model.Item;
import com.example.demo.service.ItemRepository;

@DataJpaTest
public class ItemRepositoryTest {
	
	@Autowired
	private ItemRepository itemRepository;

	@Test
	@DisplayName("item_repo_find_all")
	public void testFindAll() {
		List<Item> findAll = itemRepository.findAll();
		assertEquals(3,findAll.size());
	}
}
