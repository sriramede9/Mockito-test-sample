package com.example.demo.integration.test;

//import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;


public class HamCrestTest {

	@Test
	public void learning() {
		List<Integer> nums = Arrays.asList(1, 2, 3, 4);
		assertThat(nums, hasSize(4));
	}
}
