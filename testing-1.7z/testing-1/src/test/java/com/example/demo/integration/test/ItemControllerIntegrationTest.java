package com.example.demo.integration.test;

import org.hibernate.internal.build.AllowSysOut;
import org.json.JSONException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ItemControllerIntegrationTest {

	@Autowired
	private TestRestTemplate testRestTemplate;

	@Test
	@DisplayName("all_items_integration_test")
	void contextLoads() throws JSONException {

		ResponseEntity<String> forEntity = testRestTemplate.getForEntity("/all-items", String.class);

		if (forEntity.hasBody()) {
		System.out.print(forEntity.getBody());
			JSONAssert.assertEquals("[{id:1,name:\"db-item\"},{id:2,name:\"db-item-2\"},{id:3,name:\"db-item-3\"}]", forEntity.getBody(), false);
		}
	}
}
