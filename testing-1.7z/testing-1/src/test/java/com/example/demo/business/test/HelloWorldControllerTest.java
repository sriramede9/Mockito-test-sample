package com.example.demo.business.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.demo.HelloController;

//@SpringBootTest
@RunWith(SpringRunner.class)
@WebMvcTest(HelloController.class)
class HelloWorldControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	@DisplayName("hello_world_controller_test")
	void hello_world_basic_test() throws Exception {

		RequestBuilder accept = MockMvcRequestBuilders.get("/hello-world").accept(MediaType.APPLICATION_JSON);
//		System.out.println("hey");

		MvcResult andReturn = mockMvc.perform(accept)
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(content().string("YoLo"))
				.andReturn();

//		assertEquals("YoLo", andReturn.getResponse().getContentAsString());

	}

}
