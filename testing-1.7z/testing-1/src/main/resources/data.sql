DROP TABLE IF EXISTS item;

CREATE TABLE item (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  name VARCHAR(250) NOT NULL,
  price INT NOT NULL,
  quantity INT DEFAULT NULL
);

--create table item (id integer not null, name varchar(255), price integer not null, quantity integer not null, primary key (id))

insert into item (id,name,price,quantity) values (1,'db-item',10,100);
insert into item (id,name,price,quantity) values (2,'db-item-2',5,22);
insert into item (id,name,price,quantity) values (3,'db-item-3',8,16);
