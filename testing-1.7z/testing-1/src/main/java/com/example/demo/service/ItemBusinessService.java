package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Item;

@Service
public class ItemBusinessService {

	@Autowired
	private ItemRepository itemRepository;

	public Item getHardcodedItem() {
		return new Item(1, "ball", 10, 100);
	}

	public Item getFromRepositoryItem() {
		return itemRepository.findById(1).get();
	}

	public List<Item> getAllItemsRepositoryItem() {
		List<Item> itemList = itemRepository.findAll();

		for (Item i : itemList) {
			i.setValue(i.getPrice() * i.getQuantity());
		}

		return itemList;
	}

}
