package com.example.demo.business;

public class BusinessClass {

	SomeDataService someDataService;

	public BusinessClass() {
		super();
	}

	public BusinessClass(SomeDataService someDataService) {
		super();
		this.someDataService = someDataService;
	}

	public SomeDataService getSomeDataService() {
		return someDataService;
	}

	public void setSomeDataService(SomeDataService someDataService) {
		this.someDataService = someDataService;
	}

	public int calculateSum(int a[]) {

		int sum = 0;

		for (int value : a) {
			sum += value;
		}

		return sum;

	}

	public int calculateSumDataService() {

		int a[] = someDataService.retrieveAllData();

		int sum = 0;

		for (int value : a) {
			sum += value;
		}

		return sum;

	}
}
