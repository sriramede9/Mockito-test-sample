package com.example.demo.business;

public class SomeDataServeImpl implements SomeDataService {

	public int[] retrieveAllData() {
		// TODO Auto-generated method stub
		int a[] = { 1, 2, 3, 4 };
		return a;
	}

}
