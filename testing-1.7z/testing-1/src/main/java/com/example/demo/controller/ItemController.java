package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Item;
import com.example.demo.service.ItemBusinessService;

@RestController
public class ItemController {
	
	@Autowired
	private ItemBusinessService itemBusinessService;

	@GetMapping("/d-world")
	public Item hello() {
		return new Item(1,"ball",10,100);
	}
	
	@GetMapping("/db-world")
	public Item hello_from_business_service() {
		return itemBusinessService.getFromRepositoryItem();
	}
	
	@GetMapping("/all-items")
	public List<Item> all_items_from_business_service() {
		return itemBusinessService.getAllItemsRepositoryItem();
	}
}
