package com.example.demo.business;

public interface SomeDataService {

	int[] retrieveAllData();

}
